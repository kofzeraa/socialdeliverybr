import 'package:sixam_mart/interfaces/repository_interface.dart';

abstract class OnlinePaymentRepoInterface<T> implements RepositoryInterface {}