enum CentralizeLoginType {
  otp,
  manual,
  social,
  manualAndSocial,
  manualAndSocialAndOtp,
  otpAndSocial,
  manualAndOtp,
}